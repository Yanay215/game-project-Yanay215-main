﻿using var game = new GameProject.GameEngine();
game.Run();